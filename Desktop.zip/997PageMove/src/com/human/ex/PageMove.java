package com.human.ex;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class PageMove
 */
@WebServlet("/PageMove")
public class PageMove extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PageMove() {
        super();
        
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setAttribute("id", "Choi");
		
		Boolean flag = false;
		if(flag) {
			//화면 이동 방식 : 1. redirect방식
			response.sendRedirect("PageMove2?name="+request.getParameter("name")+"&id="+request.getAttribute("id"));
	//		response.sendRedirect("PageMove3"); //오류발생
		}else {
			//화면 이동 방식 : 2. forwarding방식
			RequestDispatcher dispatcher = request.getRequestDispatcher("PageMove2"); //객체생성
			dispatcher.forward(request, response);
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
