package com.human.ex;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class MainpageServlet
 */
@WebServlet("/MainpageServlet")
public class MainpageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MainpageServlet() {
        super();
        
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//한글처리 
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		//스트림생성
		PrintWriter out = response.getWriter();
		
		boolean flag=true;
		HttpSession session = request.getSession(); //session얻어오기
		String id= (String)session.getAttribute("id");
		System.out.println(id);
		
		if(id==null) {
			flag=true;
		}else {
			flag=false;
		}
		out.println("<html><head></head><body>");
		if(flag) {
			out.println("<br>로그인<br>");
			
			String result="<form action='SessionLogin' method=get name='login'>"+"<br>id<input type='text' name='id'>"+
			"<br>password<input type='password' name='password'><br>"+"<input type='submit' value='로그인'></form>";
			out.println(result);
			
		}else {
			out.println("<br>로그아웃<br>");
			out.println("<a href='SessionLogout'>로그아웃</a>");
			
		}
		out.println("</body></html>");
		}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
