package com.human.ex;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CookieMade
 */
@WebServlet("/CookieMade")
public class CookieMade extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CookieMade() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//한글처리 
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		
		//쿠키생성
		Cookie cookie = new Cookie("name","CHOI");
		//쿠키 시간설정
		cookie.setMaxAge(15); //초단위 설정 . 0이면 삭제
		cookie.setMaxAge(60*60*24*365);
		//쿠키 저장
		response.addCookie(cookie);
		//기존에 있던 cookie key값으로 생성해서 전송하면 새로운 이름으로 저장됨.
		
		//쿠키 여러개 생성
		cookie=new Cookie("name2","Hong");
		cookie.setMaxAge(10);
		cookie.setMaxAge(60*60*24*365);
		response.addCookie(cookie);
		
		//스트림 생성
		PrintWriter out = response.getWriter();
		out.println("<html><head></head><body>");
		out.println("<br>쿠키가 생성됨<br>");
		out.println("</body></html>");
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
