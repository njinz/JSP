package com.human.ex;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CookieSelect
 */
@WebServlet("/CookieSelect")
public class CookieSelect extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CookieSelect() {
        super();
        
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//한글처리 
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		//스트림생성
		PrintWriter out = response.getWriter();
		
		//쿠키 유무 확인
		String cookie = request.getHeader("Cookie");
		System.out.println(cookie);
		
		if(cookie!=null) {
			out.println("<html><head></head><body>");
			Cookie cookies[]=request.getCookies();
			for(Cookie c:cookies) {
//				if(c.equals("name2")) {
				out.println("<br>"+c.getName());
				out.println(" "+c.getValue());
				out.println(" "+c.getMaxAge());
//				}
			}
			out.println("<br>쿠키가 생성됨.<br>");
			out.println("</body></html>");
			
		}else {
			out.println("<html><head></head><body>");
			out.println("<br>쿠키가 없습니다.<br>");
			out.println("</body></html>");
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
