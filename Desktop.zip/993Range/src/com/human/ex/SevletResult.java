package com.human.ex;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class SevletResult
 */
@WebServlet("/SevletResult")
public class SevletResult extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SevletResult() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//name1 : 값 가져올 수 없다. (지역변수)
		//name2 : sendRedirect 나 직접접근하면 x -> forward 만 가능 
		System.out.println((Integer)request.getAttribute("name2"));
		//name3 : 
		HttpSession session = request.getSession();
		System.out.println((Integer)session.getAttribute("name3"));
		//name4 :
		ServletContext application=request.getServletContext();
		System.out.println((Integer)application.getAttribute("name4"));
		//name5 :
		System.out.println(ServletScope.name5);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
