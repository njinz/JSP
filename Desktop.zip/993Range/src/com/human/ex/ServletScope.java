package com.human.ex;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ServletScope
 */
@WebServlet("/ServletScope")
public class ServletScope extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public static int name5=10;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletScope() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//객체 저장범위 page<request<session<application
		//page 사용 x
		int name1 = 10;
		//request
		request.setAttribute("name2", 40);
		//session
		HttpSession session = request.getSession();
		session.setAttribute("name3", 44);
		//request.getSession().setAttribute("name2", 44);
		//application
		ServletContext application=request.getServletContext();
		application.setAttribute("name4", 55);
		//redirect
//		response.sendRedirect("ServletResult");
		RequestDispatcher dispatcher = request.getRequestDispatcher("ServletResult");
		dispatcher.forward(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
